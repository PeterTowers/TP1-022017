Projeto do Game of Life na linguagem Scala.

GoLScala_TM É o projeto com design Template Method;
GoLScala_ST Design Strategy;
GoLScala_ID Implementa Injeção de Dependência associada ao Template Method;

Repositório no GitHub: https://github.com/PeterTowers/TP1-022017/tree/master/GoLScala
Todos os três projetos foram feitos por:
Pedro Lucas Silva Haga Torres 16/0141575
