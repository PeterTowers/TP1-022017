# GameOfLife-SPartial
A implementation of the main architecture of game of life in Scala.

-------------
Implementação do Game of Life em Scala. A primeira versão tem várias falhas de design.

---
Esta implementação é em design Template Method com Injeção de Dependência.
